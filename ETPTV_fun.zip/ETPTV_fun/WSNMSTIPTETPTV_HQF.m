function [tenB, tenT,M1] = WSNMSTIPTETPTV_HQF(tenD, lambda, mu,C,p, param,I)

% Solve the WSNM problem 
% ---------------------------------------------
% Input:
%       tenD       -    n1*n2*n3 tensor
%       lambda  -    >0, parameter
%       mu-      regelarization parameter
%       p    -    key parameter of Schattern p norm
%
% Output:
%       tenB       -    n1*n2*n3 tensor
%       tenT       -    n1*n2*n3 tensor
%       change     -    change of objective function value
preTnnT= 0;
NOChange_counter = 0;
maxIter = 100;
change=zeros(1,maxIter);
tol = 1e-6;
rho     = 1.2;%1.2
if (~isfield(param,'Alpha'))
    Alpha = 1;
else
    Alpha = param.Alpha;
end

if (~isfield(param,'lr_init'))
    lr_init = 'SVD';
else
    lr_init = param.lr_init;
end

if (~isfield(param,'initial_rank'))
    r0 = 1;
else
    r0 = param.initial_rank;
end

if (~isfield(param,'Rank'))
    r = ceil(0.3*p*ones(1,3));
else
    r = param.Rank;
end

[M,N,p] = size(tenD);
sizeD   = size(tenD); 
max_mu   = 1e6;
mu      = 2e-3;% 2e-3
D        = zeros(M*N,p); 
weightTenT = ones(size(D)) ;
%%
Y       = reshape(tenD,M*N,p);
for i=1:p
    bandp = tenD(:,:,i);
    D(:,i)= bandp(:);
end
% normD   = norm(D,'fro');
normD = norm(D(:));

%% FFT setting
h               = sizeD(1);
w               = sizeD(2);
d               = sizeD(3);
%%
Eny_x   = ( abs(psf2otf([+1; -1], [h,w,d])) ).^2  ;
Eny_y   = ( abs(psf2otf([+1, -1], [h,w,d])) ).^2  ;
Eny_z   = ( abs(psf2otf([+1, -1], [w,d,h])) ).^2  ;
Eny_z   =  permute(Eny_z, [3, 1 2]);
determ  =  Eny_x + Eny_y + Eny_z;

%% Initializing optimization variables
X              = reshape(tenD,M*N,p);
E              = Y - X;
M1 =zeros(size(D));  % multiplier for D-X-E
M2 =zeros(size(D));  % multiplier for Dx_X-U_x*V_x
M3 =zeros(size(D));  % multiplier for Dy_X-U_y*V_y
M4 =zeros(size(D));  % multiplier for Dz_X-U_z*V_z
iter = 0;
while iter<maxIter
    iter          = iter + 1;
    
    %% weight of TV image
    if mod(iter,5)==0
        r0 = r0+1;
    end
    
    [u0, s0, v0] = svd(reshape(X,M*N,p), 'econ');
    X0        = u0(:,1:r0)*s0(1:r0,1:r0)*v0(:,1:r0)';
    
    W_s            = zeros(M*N,3);
    tmp_dx         = reshape(diff_x(X0,sizeD),[M*N,p]);
    [u,s,~]        = svd(tmp_dx,'econ');
    U_x            = u(:,1:r(1));
    
    tmp_dy         = reshape(diff_y(X0,sizeD),[M*N,p]);
    [u,s,~]        = svd(tmp_dy,'econ');
    U_y            = u(:,1:r(2));
    
    tmp_dz         = reshape(diff_z(X0,sizeD),[M*N,p]);
    [u,s,~]        = svd(tmp_dz,'econ');
    U_z            = u(:,1:r(3));
    
    Y_dx = abs(mean(tmp_dx,2));
    Y_dy = abs(mean(tmp_dy,2));
    Y_dz = abs(mean(tmp_dz,2));
    
    W_s(:,1) = Y_dx(:)/max(Y_dx(:));
    W_s(:,2) = Y_dy(:)/max(Y_dy(:));
    W_s(:,3) = Y_dz(:)/max(Y_dz(:));
    clear W_s1 W_s2 W_s3 Y_dx Y_dy Y_dz
    W_s      = 1./(W_s + 5e-2);
    W_s      = W_s / max(W_s(:));
    %% -Update V_x and V_y and V_z
    tmp_x         = tmp_dx+M2/mu;
    [u,s,v]       = svd(tmp_x,'econ');
    U_x           = u(:,1:r(1))*s(1:r(1),1:r(1));
    V_x           = ( v(:,1:r(1))' )';
    
    tmp_y         = tmp_dy+M3/mu;
    [u,s,v]       = svd(tmp_y,'econ');
    U_y           = u(:,1:r(2))*s(1:r(2),1:r(2));
    V_y           = ( v(:,1:r(2))' )';
    
    tmp_z         = tmp_dz+M4/mu;
    [u,s,v]       = svd(tmp_z,'econ');
    U_z           = u(:,1:r(3))*s(1:r(3),1:r(3));
    V_z           = ( v(:,1:r(3))' )';
    %% -Update U_x and U_y and U_z
    weight        = repmat(W_s(:,1),[1,r(1)]);
    U_x           = softthre(U_x, lambda/mu*weight);
    weight        = repmat(W_s(:,2),[1,r(2)]);
    U_y           = softthre(U_y, lambda/mu*weight);
    weight        = repmat(W_s(:,3),[1,r(3)]);
    U_z           = softthre(U_z, lambda/mu*weight);
    %% -Updata X
    % solve TV by FFT algorithm: relatively low accurary, less cost time
    diffT_p  = diff_xT(mu*U_x*V_x'-M2,sizeD)+diff_yT(mu*U_y*V_y'-M3,sizeD);
    diffT_p  = diffT_p + diff_zT(mu*U_z*V_z'-M4,sizeD);
    numer1   = reshape( diffT_p + mu*(D(:)-E(:)) + M1(:), sizeD);
    x        = real( ifftn( fftn(numer1) ./ (mu*determ + mu) ) );
    X        = reshape(x,[M*N,p]);
%% HQF
T = D-X+M1/mu;     
    t_m_n = T(:);
     ip = 10;
    scale = 10*1.4815*median(abs(t_m_n - median(t_m_n)));%10
    scale =min([scale ip*1.4815*median(abs(t_m_n - median(t_m_n)))]);

    sigma = ones(M*N,p)*scale;
    ONE_1=ones(M*N,p);
    ONE_1(abs(T-median(t_m_n))-sigma<0)=0;
    E = T.*ONE_1;    
    %% stop criterion
    leq1 = D -X -E;
    leq2 = reshape(diff_x(X,sizeD),[M*N,p])- U_x*V_x';
    leq3 = reshape(diff_y(X,sizeD),[M*N,p])- U_y*V_y';
    leq4 = reshape(diff_z(X,sizeD),[M*N,p])- U_z*V_z';
        M1 = M1 + mu*leq1;
        M2 = M2 + mu*leq2;
        M3 = M3 + mu*leq3;
        M4 = M4 + mu*leq4;
        mu = min(max_mu,mu*rho);
stopCriterion = norm(D(:) - X(:) - E(:)) / normD;
change(iter)=(stopCriterion);
    currTnnT=tubalrank(E,0);
if currTnnT == preTnnT
    NOChange_counter=NOChange_counter +1;
else
    NOChange_counter = 0;
end
 if (stopCriterion < tol) || (NOChange_counter >=1)
    break;
end             
    preTnnT = currTnnT; 
    disp(['#Iteration ' num2str(iter) ' trankT ' ...
        num2str(currTnnT) ...
        ' stopCriterion ' num2str(stopCriterion) ]);
end
tenB = reshape(X,[M,N,p]);
tenT = reshape(E,[M,N,p]);
end